package com.example.tourapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
